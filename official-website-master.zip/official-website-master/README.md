# Steps to run this website on local server

# 1. install node.js on your device. (Ignore this step if already installed)
# 2. change directory to the cloned repository folder
# 3. run following commands on your terminal: 
#    a. npm install
#    b. nodemon server
# 4. Open http://localhost:3000 on your browser
